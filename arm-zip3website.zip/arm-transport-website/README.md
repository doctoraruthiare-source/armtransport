# ARM Transport — website package

One self-contained page: `index.html`. No build step. Upload the folder to any static host
(Netlify, Vercel, Cloudflare Pages, cPanel public_html) and it works as is.

Three.js, GSAP and the model decoders load from public CDNs (jsdelivr, cdnjs); fonts from Google Fonts.

## Before going live — find and replace in index.html
- `01632 960 000` and `+441632960000` → the real phone number
- `hello@armtransport.example` → the real email
- Footer: company number, address, O-licence number, insurance cover, VAT number
- Section copy: pallet counts, payloads, cut-off times, delivery areas — currently industry-standard placeholders

## Lead capture
In the script's `CONFIG`:
- `leadEndpoint: ''` — set to a Formspree / Netlify Forms / own-API URL and the quote form POSTs JSON there.
  Left empty, the form opens a pre-filled email to `leadEmail` instead.

## Real truck models (optional, recommended)
1. Buy licensed GLB models (web/commercial licence) and run each through `optimise-models.sh`
   (needs Node 18+ and `npm i -g @gltf-transform/cli`).
2. Put the results in `models/` and point `CONFIG.models` at them, e.g.
   `artic: 'models/artic.glb', curtainsider: 'models/curtainsider.glb', ...`
3. Check `CONFIG.modelOptions.default`: `forward` is the axis the nose points along in the file,
   `wheels` matches the wheel node names (rename to `wheel_FL`, `wheel_RR`… if needed).
Until a model is supplied for a slot, the built-in vehicle is shown.
