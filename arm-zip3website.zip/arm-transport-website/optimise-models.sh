#!/usr/bin/env bash
# Prepare a high-detail truck model for the ARM Transport page without visibly simplifying it.
#
#   needs Node 18+ and:  npm i -g @gltf-transform/cli
#   usage:               ./optimise-models.sh source/tractor-trailer.glb models/artic.glb
#
# What it does (and does not do):
#   - keeps every triangle, normal, UV and node name; nothing is decimated or flattened, so wheel and
#     door nodes keep working in the page
#   - dedup + prune + weld: removes duplicate data and unused nodes, merges identical vertices
#   - textures: resized to 2048 px and re-encoded as WebP (a 4K cab texture gains little at page scale)
#   - geometry: EXT_meshopt_compression, decoded in the browser by meshopt_decoder.js (already loaded by the page)
#
# Then point the page at the result in CONFIG.models, e.g.  artic: 'models/artic.glb'
# and check in CONFIG.modelOptions that `forward` matches the file ('+z' default) and that the wheel
# nodes match the `wheels` pattern (rename nodes to "wheel_FL" etc. in Blender if they do not).
set -euo pipefail
in="${1:?source .glb}"; out="${2:?output .glb}"
mkdir -p "$(dirname "$out")"
tmp="$(mktemp -d)"
gltf-transform dedup   "$in"            "$tmp/1.glb"
gltf-transform prune   "$tmp/1.glb"     "$tmp/2.glb"
gltf-transform weld    "$tmp/2.glb"     "$tmp/3.glb"
gltf-transform resize  "$tmp/3.glb"     "$tmp/4.glb" --width 2048 --height 2048
gltf-transform webp    "$tmp/4.glb"     "$tmp/5.glb" --quality 86
gltf-transform meshopt "$tmp/5.glb"     "$out"       --level medium
rm -rf "$tmp"
echo
gltf-transform inspect "$out" | sed -n '1,40p'
echo
echo "Done: $out  ($(du -h "$out" | cut -f1))"
echo "Budget guide: hero artic <= 12 MB and ~600k triangles; each rigid <= 8 MB; van <= 5 MB. Anything larger still works, it just loads slower."
